#define BE_AIO64
#include <lio_listio.c>
