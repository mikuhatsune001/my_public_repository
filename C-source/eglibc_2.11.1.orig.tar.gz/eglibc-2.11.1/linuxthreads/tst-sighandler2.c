#define TIMED
#include "tst-sighandler1.c"
