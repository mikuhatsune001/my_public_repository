#include "../ia64/pt-sigsuspend.c"
